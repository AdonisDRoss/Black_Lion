PNG on flat #FF00FF. Names in README.md.
