# LAYER 380 — LUNA & THE WHIP

## In the build

- **The grapple whip draws as a whip.** It reuses the existing `g.grap` roof grapple, so
  scaling to roofs already worked — what changed is the line. It now bows perpendicular to the
  throw, biggest in the middle, with a travelling ripple, and the bow collapses to nothing as
  it bites. Same idea as the tazer crackle: sampled along its length and displaced, not a taut
  string from frame one. Lavender, so it reads as hers.
- **Maxine's kit** — `helmet`, `wire`, `whip`, `sonic: 6`, plus `optics` and `quiet` flags.
  No gun; the Lion keeps that line. Smoke cut from 50 to 30 — she is not Rio.
- **LUNA** is in `MOTONAME`, and there is now a `MOTO_LAMP` table. Every other bike in the
  city runs a warm tungsten beam because that is what a 1986 headlight looks like. Luna does
  not: `212,178,255` core, `196,150,255` beam. At night you can tell it is her from three
  blocks away without seeing the rider.

## Art in `assets/sewer/` — 22 covers, cut and named

Cut on a 6×4 grid rather than by blob, because the sheet's grid lines weld every cover into a
single component otherwise — the same failure as the motel sheet.

`sw_cover_sewer` · `sw_cover_sewer2` · `sw_cover_rust` · `sw_cover_worn` · `sw_cover_plain`
· `sw_cover_broken` · `sw_cover_shattered` · `sw_cover_star` · `sw_cover_radial`
· `sw_cover_hex` · `sw_cover_waffle` · `sw_cover_brick` · `sw_cover_dot` · `sw_cover_cross`
· `sw_cover_square` · `sw_cover_vent` · `sw_cover_dpw` · `sw_cover_dpw2` · `sw_cover_water`
· `sw_cover_city` · `sw_hatch_open` · `sw_hatch_open_lip`

**Not yet registered in `game.jsx`** — these are the art for the sewer hatches, and the hatches
themselves are not built. Registering plates for a system that does not exist is how you end up
with eight roof plates nobody draws.

`sw_cover_city` reads EMBER FLATS. That is fine — Ember Flats is a district in the city, so it
is the cover for that parish specifically.

**Known blemish:** about seven covers keep a 2–3 px magenta nub at the very top where the
sheet's grid line was thickest. Trim in an editor, or send the sheet as PNG and I will re-cut.

## Also in this zip

`assets/sov/` and `assets/race/` — the 17 named cuts from last turn, unchanged.
